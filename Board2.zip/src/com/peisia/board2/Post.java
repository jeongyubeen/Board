package com.peisia.board2;

public class Post { 
	String ti; 
	String con;
	String id;
	int no;
	
	public Post(String ti, String con, String id, int no) {
		super();
		this.ti = ti;
		this.con = con;
		this.id = id;
		this.no = no;
	}
	
	
}
