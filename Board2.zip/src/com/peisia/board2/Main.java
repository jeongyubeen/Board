package com.peisia.board2;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		ArrayList<Post> posts = new ArrayList<>();
//		posts.add(new Post("테스트1 ","테스트입니다1 ","테슷 ", 1));

		Scanner sc = new Scanner(System.in);
		LocalDateTime now = LocalDateTime.now();
		
		
		loop:
		while (true) {

			System.out.println("[1. 글쓰기, 2.글 리스트, 3. 글 불러오기, 4.글 수정하기, 5.글 삭제하기, e:프로그램 종료]");
			String cmd = sc.next();
					
			switch (cmd) { 
		
				case "1":
						System.out.println("***** 글쓰기*****");
						System.out.print("아이디 입력 : ");
						String id = sc.next();
						System.out.print("제목 입력 : ");
						String ti = sc.next();
						System.out.print("내용 입력 : ");
						String con = sc.next();
						System.out.print("번호 입력 : ");
						int no = sc.nextInt();
						DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy년 M월 dd일 hh시 mm분");
						String nowString = now.format(dateTimeFormatter);
						System.out.println(nowString);
												
						posts.add(new Post(id, ti, con, no));
					break;
					
				case "2":
					System.out.println("***** 글 리스트*****");
					
					for(int i = 0; i<posts.size(); i++) {
						System.out.println("아이디 :"+posts.get(i).id+" 글제목:"+posts.get(i).ti+" 글 내용:"+posts.get(i).con+" 글 번호:"+posts.get(i).no);
						
					}
					break;
					
				case "3":
					System.out.println("***** 글 불러오기*****");
					System.out.print("불러올 아이디 입력 :");
					
					String RId = sc.next();
					for(int i = 0; i<posts.size(); i++) {
						if(posts.get(i).id.equals(RId)) {
							System.out.println("아이디 :"+posts.get(i).id);
							System.out.println("글제목 :"+posts.get(i).ti);
							System.out.println("내용 :"+posts.get(i).con);				
						}
					}
					break;
					
				case "4":
					System.out.println("***** 글 수정하기*****");
					System.out.println("수정할 아이디를 입력하세요.");
					
					String RId2 = sc.next();
					for(int i = 0; i<posts.size(); i++) {
						if(posts.get(i).id.equals(RId2)) {
							System.out.println("글제목 :");
							String reTi = sc.next();
							posts.get(i).ti = reTi;
							
							System.out.println("내용 :");				
							String reCon = sc.next();
							posts.get(i).con = reCon;	
						}
					}
					break;
					
				case "5":
					System.out.println("***** 글 삭제하기*****");
					System.out.println("삭제할 글 번호 입력");
					
					String DelId = sc.next();
					for(int i = 0; i<posts.size(); i++) {
						if(posts.get(i).id.equals(DelId)) {
							System.out.println("게시물을 삭제합니다.");
							posts.remove(i);
						}
					}
					
					break;

				case "e":
					System.out.println("***** 프로그램 종료*****");
					break loop;
			}
		//안녕하세용 ^^ 왔다갑니다 ^^~!!
		}
	}
}
